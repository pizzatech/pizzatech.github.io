A Pen created at CodePen.io. You can find this one at http://codepen.io/mycnlz/pen/aNNExj.

 My login form to the Daily UI Challenge #001. 